let cart = JSON.parse(localStorage.getItem("cart")) || [];

function renderProducts(list = PRODUCTS) {
    const grid = document.getElementById("productsGrid");
    grid.innerHTML = "";

    list.forEach(p => {
        const finalPrice = p.price - (p.price * p.discount / 100);

        grid.innerHTML += `
        <div class="bg-white rounded-2xl shadow p-4 relative">
            <span class="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
                -${p.discount}%
            </span>
            <img src="${p.image}" class="w-full h-40 object-cover rounded-xl mb-3">
            <h3 class="font-semibold text-sm mb-1">${p.name}</h3>
            <div class="text-yellow-400 text-sm mb-1">⭐ ${p.rating}</div>
            <p class="text-gray-400 line-through text-sm">
                Rp ${p.price.toLocaleString()}
            </p>
            <p class="text-blue-600 font-bold mb-2">
                Rp ${finalPrice.toLocaleString()}
            </p>
            <button onclick="addToCart(${p.id})"
                class="w-full bg-blue-600 text-white py-2 rounded-xl">
                Tambah
            </button>
        </div>`;
    });
}

function addToCart(id) {
    const product = PRODUCTS.find(p => p.id === id);
    cart.push(product);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartUI();
}

function updateCartUI() {
    const badge = document.getElementById("cartCount");
    if (cart.length > 0) {
        badge.textContent = cart.length;
        badge.classList.remove("hidden");
    } else {
        badge.classList.add("hidden");
    }
}

function openCart() {
    alert("Total item di keranjang: " + cart.length);
}

function toggleDark() {
    document.body.classList.toggle("bg-gray-900");
    document.body.classList.toggle("text-white");
}

document.addEventListener("DOMContentLoaded", () => {
    renderProducts();
    updateCartUI();

    setTimeout(() => {
        document.getElementById("splashScreen").style.display = "none";
    }, 1500);
});
