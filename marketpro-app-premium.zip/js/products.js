const PRODUCTS = [
{
    id: 1,
    name: "Motor Sport 150cc",
    price: 25000000,
    discount: 10,
    rating: 4.5,
    category: "Kendaraan",
    image: "https://picsum.photos/400/300?1"
},
{
    id: 2,
    name: "Kaos Pria Premium",
    price: 99000,
    discount: 20,
    rating: 4.8,
    category: "Fashion",
    image: "https://picsum.photos/400/300?2"
},
{
    id: 3,
    name: "Laptop Gaming RTX",
    price: 15000000,
    discount: 5,
    rating: 4.7,
    category: "Elektronik",
    image: "https://picsum.photos/400/300?3"
}
];